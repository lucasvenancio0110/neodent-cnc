import { APP_NAME, APP_VERSION, API_BASE } from "./core/config.js";
import * as api from "./core/api.js";
import * as auth from "./core/auth.js";
import * as utils from "./core/utils.js";
import * as permissions from "./core/permissions.js";
import { renderShell } from "./components/navbar.js";
import { toast } from "./components/toast.js";
import { openModal, closeModal } from "./components/modal.js";
import { createMachineCard } from "./components/machine-card.js";

window.NeodentCNC = {
  APP_NAME,
  APP_VERSION,
  API_BASE,
  api,
  auth,
  utils,
  permissions,
  renderShell,
  toast,
  openModal,
  closeModal,
  createMachineCard
};

export { APP_NAME, APP_VERSION, API_BASE, api, auth, utils, permissions, renderShell, toast, openModal, closeModal, createMachineCard };
