export const API_BASE = "https://passagem-turno-api.lucassantanals0110.workers.dev";
export const APP_NAME = "Neodent CNC";
export const APP_VERSION = "neodent-cnc-cockpit-v1";
