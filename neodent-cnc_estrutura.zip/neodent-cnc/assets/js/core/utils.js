export function pad2(n) { return String(n).padStart(2, "0"); }
export function uuid() { return crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`; }
export function escapeHTML(value = "") {
  return String(value).replace(/[&<>'"]/g, ch => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", "'":"&#39;", '"':"&quot;" }[ch]));
}
export function normalizeTNL(value) {
  const digits = String(value || "").replace(/\D/g, "").slice(-3);
  return digits ? digits.padStart(3, "0") : "";
}
export function parseNumber(value) {
  if (value === "" || value == null) return NaN;
  return Number(String(value).replace(",", "."));
}
export function parseInteger(value) {
  const n = parseInt(value, 10);
  return Number.isFinite(n) ? n : 0;
}
export function parseTempoToSeconds(input) {
  if (input == null) return NaN;
  const s = String(input).trim().toLowerCase().replace(/\s+/g, "");
  if (!s) return NaN;
  const separated = s.match(/^(\d+)[,:](\d{1,2})(?:[,.]\d+)?$/);
  if (separated) {
    const minutes = Number(separated[1]);
    const seconds = Number(separated[2]);
    if (seconds >= 60) return NaN;
    return minutes * 60 + seconds;
  }
  const secondsOnly = s.match(/^(\d+(?:[.,]\d+)?)s$/);
  if (secondsOnly) return Number(secondsOnly[1].replace(",", "."));
  const minutesAndSeconds = s.match(/^(\d+)m(?:(\d{1,2})s?)?$/);
  if (minutesAndSeconds) {
    const minutes = Number(minutesAndSeconds[1]);
    const seconds = Number(minutesAndSeconds[2] || 0);
    if (seconds >= 60) return NaN;
    return minutes * 60 + seconds;
  }
  if (/^\d+$/.test(s)) return Number(s);
  const decimalMinutes = s.match(/^(\d+)\.(\d+)$/);
  if (decimalMinutes) return Number(s) * 60;
  return NaN;
}
export function parseTempoToMinutes(input) {
  const seconds = parseTempoToSeconds(input);
  return Number.isFinite(seconds) ? seconds / 60 : NaN;
}
export function fmtDate(date) {
  if (!date) return "-";
  return `${pad2(date.getDate())}/${pad2(date.getMonth() + 1)}/${date.getFullYear()}`;
}
export function fmtTime(date) {
  if (!date) return "-";
  return `${pad2(date.getHours())}:${pad2(date.getMinutes())}`;
}
export function shiftName(id) { return `${id}º turno`; }
export function getShiftWindowFor(date = new Date()) {
  const base = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0, 0);
  const mk = (h, m, plus = 0) => {
    const d = new Date(base);
    d.setDate(d.getDate() + plus);
    d.setHours(h, m, 0, 0);
    return d;
  };
  const minutes = date.getHours() * 60 + date.getMinutes();
  if (minutes < 390) return { id: 3, startDT: mk(22, 40, -1), endDT: mk(6, 30, 0) };
  if (minutes < 880) return { id: 1, startDT: mk(6, 30, 0), endDT: mk(14, 40, 0) };
  if (minutes < 1360) return { id: 2, startDT: mk(14, 40, 0), endDT: mk(22, 40, 0) };
  return { id: 3, startDT: mk(22, 40, 0), endDT: mk(6, 30, 1) };
}
export function nextShiftWindow(prevEnd, prevId) {
  const nextId = prevId === 3 ? 1 : prevId + 1;
  const base = new Date(prevEnd.getFullYear(), prevEnd.getMonth(), prevEnd.getDate(), 0, 0, 0, 0);
  const map = { 1: [6, 30, 14, 40], 2: [14, 40, 22, 40], 3: [22, 40, 6, 30] };
  const s = new Date(base); s.setHours(map[nextId][0], map[nextId][1], 0, 0);
  const e = new Date(base); e.setHours(map[nextId][2], map[nextId][3], 0, 0);
  if (nextId === 3 || e <= s) e.setDate(e.getDate() + 1);
  if (s < prevEnd) s.setTime(prevEnd.getTime());
  return { id: nextId, startDT: s, endDT: e };
}
export function formatMinutes(totalMin) {
  if (totalMin == null || !Number.isFinite(totalMin)) return "-";
  const min = Math.max(0, Math.floor(totalMin));
  return `${Math.floor(min / 60)}h ${pad2(min % 60)}min`;
}
