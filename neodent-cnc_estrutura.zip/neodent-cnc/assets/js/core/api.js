import { API_BASE } from "./config.js";
import { getToken, clearSession } from "./auth.js";

async function request(path, options = {}) {
  const token = getToken();
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  if (res.status === 401) {
    clearSession();
    window.location.href = "./login.html";
    throw new Error("Sessão expirada");
  }
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (_) { data = { raw: text }; }
  if (!res.ok || data?.ok === false) {
    throw new Error(data?.erro || data?.message || `Erro ${res.status}`);
  }
  return data;
}
export function apiGet(path) { return request(path, { method: "GET" }); }
export function apiPost(path, body = {}) { return request(path, { method: "POST", body: JSON.stringify(body) }); }
export async function login(login, senha) {
  return apiPost("/login", { login, senha });
}
