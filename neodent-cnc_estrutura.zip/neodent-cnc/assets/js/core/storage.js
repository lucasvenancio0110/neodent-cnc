const PREFIX = "venanc:";
export function getStorage(key, fallback = null) {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (_) { return fallback; }
}
export function setStorage(key, value) {
  localStorage.setItem(PREFIX + key, JSON.stringify(value));
}
export function removeStorage(key) {
  localStorage.removeItem(PREFIX + key);
}
