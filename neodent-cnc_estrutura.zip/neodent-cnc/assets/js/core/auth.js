import { getStorage, setStorage, removeStorage } from "./storage.js";
import { canAccess } from "./permissions.js";

const SESSION_KEY = "session";

export function getSession() { return getStorage(SESSION_KEY, null); }
export function setSession(session) { setStorage(SESSION_KEY, session); }
export function clearSession() { removeStorage(SESSION_KEY); }
export function getToken() { return getSession()?.token || ""; }
export function currentUser() { return getSession()?.usuario || null; }
export function currentUserLabel() {
  const u = currentUser();
  if (!u) return "Não logado";
  return `${u.nome || u.login || "Usuário"} · ${u.funcao || u.nivel_acesso || ""}`;
}
export function requireAuth(minRole = "PREPARADOR") {
  const session = getSession();
  if (!session || !session.token || !session.usuario) {
    window.location.href = "./login.html";
    return false;
  }
  const role = session.usuario.nivel_acesso || session.usuario.funcao;
  if (!canAccess(role, minRole)) {
    window.location.href = "./index.html?erro=permissao";
    return false;
  }
  return true;
}
export function logout() {
  clearSession();
  window.location.href = "./login.html";
}
