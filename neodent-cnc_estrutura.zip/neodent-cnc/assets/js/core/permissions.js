export const ROLES = {
  PREPARADOR: 10,
  TECNICO: 20,
  LIDER: 30,
  GERENCIA: 40,
  ADMIN: 50
};
export function roleLevel(role = "") { return ROLES[String(role).toUpperCase()] || 0; }
export function canAccess(role, minRole) { return roleLevel(role) >= roleLevel(minRole); }
export const PAGE_MIN_ROLE = {
  "admin": "ADMIN",
  "relatorio": "TECNICO",
  "painel": "PREPARADOR",
  "tempo-linha": "PREPARADOR",
  "preparadores": "PREPARADOR",
  "apoio": "PREPARADOR",
  "setup": "PREPARADOR",
  "historico": "PREPARADOR",
  "index": "PREPARADOR"
};
