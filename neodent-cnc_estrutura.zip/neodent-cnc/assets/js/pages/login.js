import { api, auth } from "../global.js";
const form = document.querySelector("#loginForm");
const errorBox = document.querySelector("#loginError");
form?.addEventListener("submit", async (event) => {
  event.preventDefault();
  errorBox.textContent = "";
  const data = Object.fromEntries(new FormData(form));
  try {
    const res = await api.login(data.login, data.senha);
    auth.setSession(res.session || res);
    window.location.href = "./index.html";
  } catch (err) {
    errorBox.textContent = err.message || "Não foi possível entrar.";
  }
});
