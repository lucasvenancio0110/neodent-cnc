import { renderShell, auth, toast } from "../global.js";
if (auth.requireAuth("PREPARADOR")) renderShell("setup");
document.querySelector("#setupForm")?.addEventListener("submit", (event) => {
  event.preventDefault();
  toast("Liberação de setup será conectada no Worker.", "ok");
});
