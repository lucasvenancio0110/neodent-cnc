import { renderShell, auth, toast } from "../global.js";
if (auth.requireAuth("ADMIN")) renderShell("admin");
document.querySelector("#usuarioForm")?.addEventListener("submit", (event) => {
  event.preventDefault();
  toast("Cadastro de usuário será conectado no Worker Auth.", "ok");
});
