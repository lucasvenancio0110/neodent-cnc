import { renderShell, auth } from "../global.js";
if (auth.requireAuth("PREPARADOR")) renderShell("index");
