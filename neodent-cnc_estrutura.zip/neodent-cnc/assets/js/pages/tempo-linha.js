import { renderShell, auth, utils, toast } from "../global.js";
if (auth.requireAuth("PREPARADOR")) renderShell("tempo-linha");

const form = document.querySelector("#tempoForm");
const result = document.querySelector("#tempoResult");
form?.addEventListener("input", calcular);
form?.addEventListener("submit", (event) => { event.preventDefault(); toast("Salvar leitura será conectado no Worker.", "ok"); });

function calcular() {
  const data = Object.fromEntries(new FormData(form));
  const cicloMin = utils.parseTempoToMinutes(data.ciclo);
  const meta = utils.parseInteger(data.meta);
  const produzidas = utils.parseInteger(data.produzidas);
  const saldo = Math.max(0, meta - produzidas);
  if (!Number.isFinite(cicloMin) || cicloMin <= 0 || !meta) {
    result.innerHTML = `<div class="empty-state">Preencha ciclo, meta e produzidas para calcular.</div>`;
    return;
  }
  const restMin = Math.floor(saldo * cicloMin);
  const end = new Date(Date.now() + restMin * 60000);
  const status = restMin < 480 ? "ENCERRA NESTE TURNO" : restMin < 960 ? "PRÓXIMO TURNO" : "NÃO ENCERRA";
  result.innerHTML = `
    <article class="machine-card ${restMin < 480 ? "status-manutencao" : restMin < 960 ? "status-ajuste" : "status-ok"}">
      <div class="machine-head"><div class="machine-main"><div class="machine-token">${utils.normalizeTNL(data.tnl) || "--"}</div><div class="machine-name"><strong>TNL ${utils.normalizeTNL(data.tnl) || "---"}</strong><div class="machine-mini"><span>${saldo} peças restantes</span><span>•</span><span>${utils.formatMinutes(restMin)}</span></div></div></div><span class="badge ${restMin < 480 ? "bad" : restMin < 960 ? "warn" : "ok"}">${status}</span></div>
      <div class="machine-body"><div class="machine-detail">Previsão: ${utils.fmtDate(end)} às ${utils.fmtTime(end)} · Item ${data.item || "-"}</div></div>
    </article>`;
}
