import { renderShell, auth, api } from "../global.js";
if (auth.requireAuth("TECNICO")) { renderShell("relatorio"); gerar(); }
async function gerar() {
  const area = document.querySelector("#relatorioArea");
  try {
    const data = await api.apiGet("/painel-geral");
    area.textContent = JSON.stringify(data, null, 2);
  } catch (err) { area.textContent = `Relatório aguardando API: ${err.message}`; }
}
