import { renderShell, auth, api, toast, createMachineCard } from "../global.js";
if (auth.requireAuth("PREPARADOR")) {
  renderShell("painel");
  carregarPainel();
}
async function carregarPainel() {
  const board = document.querySelector("#painelBoard");
  try {
    const data = await api.apiGet("/painel-geral");
    const items = data.ocorrencias || data.cards || [];
    board.innerHTML = "";
    if (!items.length) board.innerHTML = `<div class="empty-state">Nenhum card operacional aberto.</div>`;
    items.forEach(item => board.appendChild(createMachineCard(item, [
      { label: "Abrir", className: "btn btn-light", onClick: () => toast("Ação será conectada ao fluxo do card.") }
    ])));
  } catch (err) {
    board.innerHTML = `<div class="empty-state">Painel aguardando dados da API: ${err.message}</div>`;
  }
}
