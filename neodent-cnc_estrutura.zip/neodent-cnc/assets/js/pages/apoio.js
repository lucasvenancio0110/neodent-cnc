import { renderShell, auth, api, toast, createMachineCard } from "../global.js";
if (auth.requireAuth("PREPARADOR")) { renderShell("apoio"); carregarApoio(); }
async function carregarApoio() {
  const board = document.querySelector("#apoioBoard");
  try {
    const data = await api.apiGet("/precisa-apoio");
    const items = data.ocorrencias || data.cards || [];
    board.innerHTML = "";
    if (!items.length) board.innerHTML = `<div class="empty-state">Nenhum pedido de apoio aberto.</div>`;
    items.forEach(item => board.appendChild(createMachineCard({ ...item, status: item.status || "PRECISA APOIO" }, [
      { label: "Vou atender", className: "btn btn-primary", onClick: () => toast("Assumir apoio será conectado no Worker.") }
    ])));
  } catch (err) { board.innerHTML = `<div class="empty-state">Apoio aguardando API: ${err.message}</div>`; }
}
