import { renderShell, auth, api, utils } from "../global.js";
if (auth.requireAuth("PREPARADOR")) renderShell("historico");
const form = document.querySelector("#historicoForm");
const result = document.querySelector("#historicoResult");
form?.addEventListener("submit", async (event) => {
  event.preventDefault();
  const tnl = utils.normalizeTNL(new FormData(form).get("tnl"));
  try {
    const data = await api.apiGet(`/consulta-maquina?tnl=${encodeURIComponent(tnl)}`);
    result.innerHTML = `<pre class="machine-detail">${utils.escapeHTML(JSON.stringify(data, null, 2))}</pre>`;
  } catch (err) { result.innerHTML = `<div class="empty-state">${err.message}</div>`; }
});
