import { renderShell, auth, api, toast } from "../global.js";
if (auth.requireAuth("PREPARADOR")) renderShell("preparadores");
const form = document.querySelector("#ocorrenciaForm");
form?.addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(form));
  try {
    await api.apiPost("/abrir-ocorrencia", payload);
    toast("Ocorrência aberta.", "ok");
    form.reset();
  } catch (err) { toast(err.message, "bad"); }
});
