import { currentUserLabel, logout } from "../core/auth.js";

const NAV = [
  ["painel", "▦", "Painel", "./painel.html"],
  ["tempo-linha", "⏱", "Tempo", "./tempo-linha.html"],
  ["preparadores", "⚙", "Prep.", "./preparadores.html"],
  ["apoio", "✋", "Apoio", "./apoio.html"],
  ["setup", "✓", "Setup", "./setup.html"]
];

export function renderShell(active = "index") {
  const top = document.createElement("header");
  top.className = "topbar";
  top.innerHTML = `
    <div class="topbar-inner">
      <a class="brand" href="./index.html">
        <div class="brand-mark">NC</div>
        <div class="brand-text"><strong>Neodent CNC</strong><span>${active || "Cockpit Operacional"}</span></div>
      </a>
      <div class="nav-actions">
        <span class="user-pill">${currentUserLabel()}</span>
        <button class="btn btn-ghost" type="button" data-logout>Sair</button>
      </div>
    </div>`;
  const bottom = document.createElement("nav");
  bottom.className = "bottom-nav";
  bottom.innerHTML = NAV.map(([id, icon, label, href]) => `
    <a class="nav-item ${active === id ? "active" : ""}" href="${href}"><b>${icon}</b><span>${label}</span></a>
  `).join("") + `<a class="nav-item more ${active === "historico" || active === "relatorio" || active === "admin" ? "active" : ""}" href="./index.html"><b>⋯</b><span>Mais</span></a>`;
  document.body.prepend(top);
  document.body.appendChild(bottom);
  top.querySelector("[data-logout]")?.addEventListener("click", logout);
}
