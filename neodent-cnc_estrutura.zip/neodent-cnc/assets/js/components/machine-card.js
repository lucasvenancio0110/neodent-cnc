import { escapeHTML, normalizeTNL } from "../core/utils.js";

export function statusClass(status = "") {
  const s = String(status).toUpperCase();
  if (s.includes("SETUP")) return "status-setup";
  if (s.includes("AJUST")) return "status-ajuste";
  if (s.includes("MANUT")) return "status-manutencao";
  if (s.includes("APOIO")) return "status-apoio";
  if (s.includes("CONCLU") || s.includes("LIBER")) return "status-ok";
  return "";
}
export function badgeClass(status = "") {
  const s = String(status).toUpperCase();
  if (s.includes("SETUP")) return "setup";
  if (s.includes("AJUST")) return "ajuste";
  if (s.includes("MANUT")) return "manut";
  if (s.includes("APOIO")) return "apoio";
  if (s.includes("OBS")) return "obs";
  if (s.includes("CONCLU") || s.includes("LIBER")) return "ok";
  return "";
}
export function createMachineCard(item = {}, actions = []) {
  const card = document.createElement("article");
  const tnl = normalizeTNL(item.tnl || item.machine || item.maquina);
  const status = item.status || item.status_atual || "Sem status";
  card.className = `machine-card ${statusClass(status)}`.trim();
  card.dataset.tnl = tnl;
  card.innerHTML = `
    <div class="machine-head">
      <div class="machine-main">
        <div class="machine-token">${tnl || "--"}</div>
        <div class="machine-name">
          <strong>TNL ${tnl || "---"}</strong>
          <div class="machine-mini">
            <span>${escapeHTML(item.celula ? `Célula ${item.celula}` : "Sem célula")}</span>
            <span>•</span>
            <span>${escapeHTML(item.responsavel || item.aberto_por || "Sem responsável")}</span>
          </div>
        </div>
      </div>
      <span class="badge ${badgeClass(status)}">${escapeHTML(status)}</span>
    </div>
    <div class="machine-body">
      <div class="machine-detail">${escapeHTML(item.motivo || item.detalhe || item.observacao || item.texto_original || "Sem detalhe informado")}</div>
      <div class="machine-actions"></div>
    </div>`;
  const actionWrap = card.querySelector(".machine-actions");
  actions.forEach(action => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = action.className || "btn btn-light";
    btn.textContent = action.label;
    btn.addEventListener("click", () => action.onClick?.(item, card));
    actionWrap.appendChild(btn);
  });
  return card;
}
