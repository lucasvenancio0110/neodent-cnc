export function renderMetric(root, label, value) {
  const item = document.createElement("div");
  item.className = "metric";
  item.innerHTML = `<span>${label}</span><strong>${value}</strong>`;
  root.appendChild(item);
}
