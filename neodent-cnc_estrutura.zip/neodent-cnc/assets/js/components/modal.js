export function ensureModal() {
  let backdrop = document.querySelector("#appModal");
  if (!backdrop) {
    backdrop = document.createElement("div");
    backdrop.id = "appModal";
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `<div class="modal-card"><div class="modal-head"><strong data-modal-title></strong><button class="icon-btn" data-modal-close type="button">×</button></div><div class="modal-body" data-modal-body></div></div>`;
    document.body.appendChild(backdrop);
    backdrop.querySelector("[data-modal-close]").addEventListener("click", closeModal);
    backdrop.addEventListener("click", e => { if (e.target === backdrop) closeModal(); });
  }
  return backdrop;
}
export function openModal(title, content) {
  const modal = ensureModal();
  modal.querySelector("[data-modal-title]").textContent = title;
  const body = modal.querySelector("[data-modal-body]");
  body.innerHTML = "";
  if (typeof content === "string") body.innerHTML = content;
  else if (content) body.appendChild(content);
  modal.classList.add("open");
}
export function closeModal() {
  document.querySelector("#appModal")?.classList.remove("open");
}
